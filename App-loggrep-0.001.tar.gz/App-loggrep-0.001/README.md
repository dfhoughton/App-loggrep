App::loggrep
============

David F. Houghton
15 October, 2014

A command line utility to facilitate finding particular lines in a log file.

Installation Instructions
-------------------------

At some point I'll put this up on CPAN. In the meantime, I've included an installable tarball in the repo. If you have
cpanminus, you can install it like so

    cpanm App-loggrep-0.001.tar.gz

If you don't have cpanminus, you can install that like so:

    cpan App::cpanminus

Other Stuff
-----------

This software is copyright (c) 2014 by David F. Houghton.

Thanks to Green River. I wrote this one morning to facilitate profiling SQL queries recorded in a Rails development log.

This is free software; you can redistribute it and/or modify it under the same terms as the Perl 5 programming language system itself.
