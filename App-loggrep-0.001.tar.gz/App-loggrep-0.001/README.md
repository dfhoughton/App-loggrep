App::loggrep
============

David F. Houghton
15 October, 2014

A command line utility to facilitate finding particular lines in a log file.

Other Stuff
-----------

This software is copyright (c) 2014 by David F. Houghton.

This is free software; you can redistribute it and/or modify it under the same terms as the Perl 5 programming language system itself.
