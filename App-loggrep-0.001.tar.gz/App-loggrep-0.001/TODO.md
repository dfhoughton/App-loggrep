Things planned but unimplemented
================================

* dross buffer for after lines without explicit times
